import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fetch from "node-fetch";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, "public")));

function encodeUrl(url) {
  return Buffer.from(url, "utf8").toString("base64url");
}

function decodeUrl(encoded) {
  return Buffer.from(encoded, "base64url").toString("utf8");
}

function absolutize(url, base) {
  try {
    return new URL(url, base).toString();
  } catch {
    return url;
  }
}

function rewriteHtml(html, baseUrl, proxyPrefix) {
  return html.replace(
    /(href|src|action)\s*=\s*"(.*?)"/gi,
    (match, attr, value) => {
      if (value.startsWith("javascript:") || value.startsWith("data:")) {
        return match;
      }
      const abs = absolutize(value, baseUrl);
      const proxied = proxyPrefix + encodeUrl(abs);
      return `${attr}="${proxied}"`;
    }
  );
}

// frontend
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// proxy route: /proxy/<base64url>
app.get("/proxy/:encoded", async (req, res) => {
  let target;
  try {
    target = decodeUrl(req.params.encoded);
    new URL(target);
  } catch {
    return res.status(400).send("Invalid target");
  }

  try {
    const upstream = await fetch(target, {
      redirect: "follow",
      headers: {
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
          "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
      }
    });

    const contentType = upstream.headers.get("content-type") || "";
    const buffer = await upstream.buffer();

    if (contentType.includes("text/html")) {
      let html = buffer.toString("utf8");
      const proxyPrefix = "/proxy/";
      html = rewriteHtml(html, target, proxyPrefix);
      res.setHeader("content-type", "text/html; charset=utf-8");
      return res.send(html);
    }

    // non-HTML: just pipe through
    res.setHeader("content-type", contentType);
    return res.send(buffer);
  } catch (e) {
    console.error(e);
    return res.status(502).send("Upstream error");
  }
});

app.listen(PORT, () => {
  console.log(`Titanium-style proxy on http://localhost:${PORT}`);
});
